package com.api.book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiBookExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
